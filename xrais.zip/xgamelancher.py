import tkinter as tk
from tkinter import ttk
import subprocess
from win32api import GetSystemMetrics

class LauncherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Launcher")
        self.geometry(f"{GetSystemMetrics(1)}x{GetSystemMetrics(0)}")  # Adjust the size here

        self.label = ttk.Label(self, text="Select an application:")
        self.label.pack(pady=10)

        self.app_buttons = []

        self.create_app_button('tic tac to', 'tictacto.py')
        self.create_app_button('hangman', 'hangman.py')
        self.create_app_button('snake', 'snake.py')
        self.create_app_button('xtools', 'xtoollancher.py')

    def create_app_button(self, app_name, app_file):
        button = ttk.Button(self, text=app_name, command=lambda: self.run_app(app_file))
        button.pack(padx=20, pady=5)
        self.app_buttons.append(button)

    def run_app(self, app_file):
        subprocess.Popen(["python", app_file])

if __name__ == "__main__":
    app = LauncherApp()
    app.mainloop()

