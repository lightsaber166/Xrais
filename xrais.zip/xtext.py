import tkinter as tk
from tkinter import filedialog

class TextEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Text Editor")

        # Create a text widget
        self.text_widget = tk.Text(root)
        self.text_widget.pack(fill=tk.BOTH, expand=True)

        # Create a menu bar
        self.menu_bar = tk.Menu(root)
        self.root.config(menu=self.menu_bar)

        # Create a File menu
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_command(label="Save", command=self.save_file)
        self.file_menu.add_command(label="Save As", command=self.save_file_as)  # Added "Save As" option
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=root.quit)

    def open_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, "r") as file:
                content = file.read()
                self.text_widget.delete("1.0", tk.END)
                self.text_widget.insert(tk.END, content)

    def save_file(self):
        file_path = getattr(self, "file_path", None)  # Use the existing file_path if available
        if not file_path:
            file_path = filedialog.asksaveasfilename(filetypes=[("Text Files", "*.txt")])
            if not file_path:
                return  # User canceled save

        content = self.text_widget.get("1.0", tk.END)
        with open(file_path, "w") as file:
            file.write(content)
        self.file_path = file_path  # Store the file_path for future saves

    def save_file_as(self):
        file_path = filedialog.asksaveasfilename(filetypes=[("Text Files", "*.txt")])
        if file_path:
            content = self.text_widget.get("1.0", tk.END)
            with open(file_path, "w") as file:
                file.write(content)
            self.file_path = file_path  # Update the file_path

if __name__ == "__main__":
    root = tk.Tk()
    app = TextEditor(root)
    root.mainloop()
