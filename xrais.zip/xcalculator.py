import tkinter as tk
import math

class ScientificCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Scientific Calculator")

        self.entry = tk.Entry(root, font=("Arial", 20), bd=10, insertwidth=4, width=14, justify='right')
        self.entry.grid(row=0, column=0, columnspan=6)

        self.create_buttons()

    def create_buttons(self):
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '=', '+',
            'C', 'sqrt', 'sin', 'cos',
            'tan', 'pow', '(', ')',
            'log10', 'ln', 'AC'
        ]

        row, col = 1, 0
        for button in buttons:
            tk.Button(self.root, text=button, padx=20, pady=20, font=("Arial", 20), command=lambda b=button: self.on_button_click(b)).grid(row=row, column=col)
            col += 1
            if col > 5:
                col = 0
                row += 1

    def on_button_click(self, button):
        if button == "=":
            try:
                expression = self.entry.get()
                expression = expression.replace('^', '**')
                result = eval(expression)
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        elif button == "C":
            self.entry.delete(0, tk.END)
        elif button == "AC":
            self.entry.delete(0, tk.END)
        elif button == "sqrt":
            try:
                value = float(self.entry.get())
                result = math.sqrt(value)
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        elif button == "sin":
            try:
                value = float(self.entry.get())
                result = math.sin(math.radians(value))
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        elif button == "cos":
            try:
                value = float(self.entry.get())
                result = math.cos(math.radians(value))
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        elif button == "tan":
            try:
                value = float(self.entry.get())
                result = math.tan(math.radians(value))
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        elif button == "pow":
            try:
                value = float(self.entry.get())
                result = math.pow(value, 2)
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        elif button == "log10":
            try:
                value = float(self.entry.get())
                result = math.log10(value)
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        elif button == "ln":
            try:
                value = float(self.entry.get())
                result = math.log(value)
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, result)
            except Exception as e:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Error")
        else:
            current_text = self.entry.get()
            self.entry.delete(0, tk.END)
            self.entry.insert(tk.END, current_text + button)

if __name__ == "__main__":
    root = tk.Tk()
    calculator = ScientificCalculator(root)
    root.mainloop()
