import tkinter as tk
from tkinter import filedialog
import pygame

class MediaPlayer:
    def __init__(self, root):
        self.root = root
        root.title("Media Player")

        pygame.init()
        self.playing = False
        self.playlist = []
        self.current_track = 0

        # Create UI elements
        self.play_button = tk.Button(root, text="Play", command=self.toggle_play)
        self.stop_button = tk.Button(root, text="Stop", command=self.stop)
        self.next_button = tk.Button(root, text="Next", command=self.play_next)
        self.prev_button = tk.Button(root, text="Previous", command=self.play_previous)
        self.volume_slider = tk.Scale(root, from_=0, to=100, orient="horizontal", label="Volume", command=self.set_volume)
        self.playlist_box = tk.Listbox(root)
        self.add_button = tk.Button(root, text="Add Media", command=self.add_media)

        # Layout UI elements
        self.play_button.pack()
        self.stop_button.pack()
        self.next_button.pack()
        self.prev_button.pack()
        self.volume_slider.pack()
        self.playlist_box.pack()
        self.add_button.pack()

        self.playback = None
        self.load_media()

    def toggle_play(self):
        if not self.playlist:
            return

        if not self.playing:
            self.play()
        else:
            self.pause()

    def play(self):
        if not self.playlist:
            return

        if not self.playing:
            self.playing = True
            pygame.mixer.music.unpause()

    def pause(self):
        if self.playing:
            self.playing = False
            pygame.mixer.music.pause()

    def stop(self):
        if self.playing:
            self.playing = False
            pygame.mixer.music.stop()

    def play_next(self):
        if not self.playlist:
            return

        self.stop()
        self.current_track = (self.current_track + 1) % len(self.playlist)
        self.play()

    def play_previous(self):
        if not self.playlist:
            return

        self.stop()
        self.current_track = (self.current_track - 1) % len(self.playlist)
        self.play()

    def set_volume(self, volume):
        volume = int(volume)
        pygame.mixer.music.set_volume(volume / 100)

    def add_media(self):
        file_path = filedialog.askopenfilename(filetypes=[("Media files", "*.mp3 *.mp4 *.wav")])
        if file_path:
            self.playlist.append(file_path)
            self.playlist_box.insert(tk.END, file_path)
            self.load_media()

    def load_media(self):
        if self.playback:
            pygame.mixer.music.stop()
        if self.playlist:
            pygame.mixer.music.load(self.playlist[self.current_track])
            pygame.mixer.music.set_volume(0.5)
            self.play()

if __name__ == "__main__":
    root = tk.Tk()
    app = MediaPlayer(root)
    root.geometry("400x400")  # Set the initial window size here
    root.mainloop()
