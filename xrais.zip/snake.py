import tkinter as tk
import random

class SnakeGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Snake Game")

        self.canvas = tk.Canvas(root, width=400, height=400, bg="black")
        self.canvas.pack()

        self.snake = [(100, 50), (90, 50), (80, 50)]
        self.food = self.create_food()
        self.direction = "Right"
        self.score = 0
        self.game_over_flag = False

        self.root.bind("<Key>", self.change_direction)
        self.move_snake()
        self.place_food()
        self.restart_button = None

    def create_food(self):
        while True:
            x = random.randint(0, 39) * 10
            y = random.randint(0, 39) * 10
            if (x, y) not in self.snake:
                return x, y

    def place_food(self):
        self.food_item = self.canvas.create_rectangle(self.food[0], self.food[1], self.food[0] + 10, self.food[1] + 10, fill="red", outline="black")

    def change_direction(self, event):
        key = event.keysym
        if (key == "Up" and self.direction != "Down") or \
           (key == "Down" and self.direction != "Up") or \
           (key == "Left" and self.direction != "Right") or \
           (key == "Right" and self.direction != "Left"):
            self.direction = key

    def move_snake(self):
        if self.direction == "Up":
            new_head = (self.snake[0][0], self.snake[0][1] - 10)
        elif self.direction == "Down":
            new_head = (self.snake[0][0], self.snake[0][1] + 10)
        elif self.direction == "Left":
            new_head = (self.snake[0][0] - 10, self.snake[0][1])
        elif self.direction == "Right":
            new_head = (self.snake[0][0] + 10, self.snake[0][1])

        self.snake.insert(0, new_head)

        if self.snake[0] == self.food:
            self.score += 10
            self.canvas.delete(self.food_item)
            self.food = self.create_food()
            self.place_food()
        else:
            self.snake.pop()

        if self.check_collision() or not (0 <= self.snake[0][0] <= 390) or not (0 <= self.snake[0][1] <= 390):
            self.game_over()
            return

        self.canvas.delete("snake")
        for segment in self.snake:
            self.canvas.create_rectangle(segment[0], segment[1], segment[0] + 10, segment[1] + 10, fill="green", outline="black", tags="snake")

        self.root.after(100, self.move_snake)

    def check_collision(self):
        return self.snake[0] in self.snake[1:]

    def game_over(self):
        self.canvas.delete("all")
        self.canvas.create_text(200, 200, text=f"Game Over\nScore: {self.score}", font=("Arial", 20), fill="white")
        self.game_over_flag = True

        if self.restart_button:
            self.restart_button.destroy()

        self.restart_button = tk.Button(self.root, text="Restart", font=("Arial", 16), command=self.restart_game)
        self.restart_button.pack()

    def restart_game(self):
        if self.game_over_flag:
            self.game_over_flag = False
            self.canvas.delete("all")
            self.snake = [(100, 50), (90, 50), (80, 50)]
            self.food = self.create_food()
            self.direction = "Right"
            self.score = 0
            self.move_snake()
            self.place_food()
            self.restart_button.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    game = SnakeGame(root)
    root.mainloop()
