import tkinter as tk
import win32api
import win32con

def create_empty_sudoku_grid(size):
    return [["" for _ in range(size)] for _ in range(size)]

def on_entry_change(row, col, var):
    try:
        value = int(var.get())
        if 1 <= value <= 9:
            sudoku_grid[row][col] = value
        else:
            var.set("")  # Clear the input if not a valid number
    except ValueError:
        var.set("")  # Clear the input if not a valid number

def create_sudoku_ui(root, grid):
    for i in range(25):  # Adjusted for a 25x25 grid
        for j in range(25):  # Adjusted for a 25x25 grid
            var = tk.StringVar()
            entry = tk.Entry(root, textvariable=var, width=2, font=("Arial", 10))  # Adjusted font size
            entry.grid(row=i, column=j, padx=1, pady=1)  # Add some padding to the grid cells
            var.trace_add("write", lambda name, index, mode, var=var, i=i, j=j: on_entry_change(i, j, var))

root = tk.Tk()
root.title("xgrid")  # Set the window title to "xgrid"

# Maximize the window
root.state('zoomed')

sudoku_grid = create_empty_sudoku_grid(25)  # Adjusted for a 25x25 grid
create_sudoku_ui(root, sudoku_grid)

# Stretch the grid columns and rows to fill the entire window
for i in range(25):  # Adjusted for a 25x25 grid
    root.grid_rowconfigure(i, weight=1)
    root.grid_columnconfigure(i, weight=1)

root.mainloop()
