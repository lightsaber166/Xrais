# drawing_app.py

import tkinter as tk
from tkinter import filedialog
import json

class DrawingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Drawing App")

        # Create a canvas for drawing
        self.canvas = tk.Canvas(root, width=800, height=600, bg="white")
        self.canvas.pack()

        # Create a color palette
        self.color_palette = tk.Frame(root, width=50, height=600)
        self.color_palette.pack(side=tk.LEFT)

        # Create a color selection circle
        self.color_selection_circle = tk.Canvas(self.color_palette, width=30, height=30, bg="white", bd=1, highlightthickness=1, relief="ridge")
        self.color_selection_circle.pack(fill=tk.X)
        self.color_selection_circle.bind("<B1-Motion>", self.move_color_selection)

        # Create an outer black circle for the color palette
        self.create_color_circle("#000000", 30)

        # Create color circles for the palette
        self.create_color_circle("#FF0000")
        self.create_color_circle("#00FF00")
        self.create_color_circle("#0000FF")
        self.create_color_circle("#FFFF00")
        self.create_color_circle("#800080")
        self.create_color_circle("#FFA500")

        # Create a brightness slider
        self.brightness_slider = tk.Scale(self.color_palette, from_=0, to=200, orient=tk.HORIZONTAL, label="Brightness", command=self.update_brightness)
        self.brightness_slider.pack(fill=tk.X)

        # Add brushes (pencil, brush, eraser) buttons
        self.create_brush_button("Pencil")
        self.create_brush_button("Brush")
        self.create_brush_button("Eraser")

        # Create a menu bar
        self.menu_bar = tk.Menu(root)
        self.root.config(menu=self.menu_bar)

        # Add File menu options
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="New", command=self.new_canvas)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_command(label="Save As", command=self.save_file)
        self.file_menu.add_command(label="Save", command=self.save)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=root.quit)

        # Initialize file-related variables
        self.current_file = None

        # Set the default brush and color
        self.current_brush = "Pencil"
        self.current_color = "#FF0000"  # Default to red

        # Bind mouse events
        self.canvas.bind("<Button-1>", self.start_drawing)
        self.canvas.bind("<B1-Motion>", self.draw)
        self.canvas.bind("<ButtonRelease-1>", self.stop_drawing)

        # Variables for drawing
        self.drawing = False
        self.last_x = None
        self.last_y = None

    def create_color_circle(self, color, size=20):
        # Create a color circle with the specified color
        color_circle = tk.Canvas(self.color_palette, width=size, height=size, bg=color, bd=0, highlightthickness=0, relief="ridge")
        color_circle.pack(fill=tk.X)
        color_circle.bind("<Button-1>", lambda event, c=color: self.select_color(c))

    def create_brush_button(self, brush_name):
        # Create a button for selecting a brush
        button = tk.Button(self.color_palette, text=brush_name, command=lambda b=brush_name: self.select_brush(b))
        button.pack(fill=tk.X)

    def select_brush(self, brush_name):
        # Set the current brush
        self.current_brush = brush_name

    def select_color(self, color):
        # Set the current drawing color
        self.current_color = color
        self.color_selection_circle.configure(bg=color)

    def move_color_selection(self, event):
        # Move the color selection circle and update the selected color
        x, y = event.x, event.y
        self.color_selection_circle.place(x=x, y=y)
        self.update_selected_color(x, y)

    def update_selected_color(self, x, y):
        # Calculate the selected color based on the position of the color selection circle
        width = self.color_selection_circle.winfo_width()
        height = self.color_selection_circle.winfo_height()
        color_percent = min(max((x / width), 0), 1)
        brightness_percent = 1 - min(max((y / height), 0), 1)
        brightness = int(brightness_percent * 255)
        adjusted_color = self.adjust_brightness(self.current_color, brightness_percent)
        r, g, b = int(adjusted_color[1:3], 16), int(adjusted_color[3:5], 16), int(adjusted_color[5:7], 16)
        r = int(r * color_percent)
        g = int(g * color_percent)
        b = int(b * color_percent)
        selected_color = "#{:02X}{:02X}{:02X}".format(r, g, b)
        self.select_color(selected_color)

    def start_drawing(self, event):
        # Start drawing
        self.drawing = True
        self.last_x = event.x
        self.last_y = event.y

    def draw(self, event):
        # Draw lines based on brush type
        if self.drawing:
            x, y = event.x, event.y
            if self.current_brush == "Pencil":
                self.canvas.create_line(self.last_x, self.last_y, x, y, fill=self.current_color, width=2)
            elif self.current_brush == "Brush":
                self.canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill=self.current_color, outline="")
            elif self.current_brush == "Eraser":
                self.canvas.create_rectangle(x - 10, y - 10, x + 10, y + 10, fill="white", outline="")
            self.last_x = x
            self.last_y = y

    def stop_drawing(self, event):
        # Stop drawing
        self.drawing = False

    def new_canvas(self):
        # Clear the canvas
        self.canvas.delete("all")

    def open_file(self):
        # Open a file and load the drawing in custom JSON format
        filename = filedialog.askopenfilename(filetypes=[("Drawing Files", "*.pnt")])
        if filename:
            with open(filename, "r") as file:
                drawing_data = json.load(file)
                self.current_brush = drawing_data["brush"]
                self.current_color = drawing_data["color"]
                self.load_drawing_lines(drawing_data["lines"])
                self.current_file = filename

    def save_file(self):
        # Save the drawing to a new file
        filename = filedialog.asksaveasfilename(defaultextension=".pnt", filetypes=[("Drawing Files", "*.pnt")])
        if filename:
            with open(filename, "w") as file:
                drawing_data = {
                    "brush": self.current_brush,
                    "color": self.current_color,
                    "lines": self.get_drawing_lines()
                }
                json.dump(drawing_data, file, indent=4)
                self.current_file = filename

    def save(self):
        # Save the drawing to the current file
        if self.current_file:
            with open(self.current_file, "w") as file:
                drawing_data = {
                    "brush": self.current_brush,
                    "color": self.current_color,
                    "lines": self.get_drawing_lines()
                }
                json.dump(drawing_data, file, indent=4)

    def get_drawing_lines(self):
        # Collect the drawing lines from the canvas
        drawing_lines = []
        for item in self.canvas.find_all():
            if self.canvas.type(item) == "line":
                coords = self.canvas.coords(item)
                color = self.canvas.itemcget(item, "fill")
                drawing_lines.append({"coords": coords, "color": color})
        return drawing_lines

    def load_drawing_lines(self, lines):
        # Load and draw the lines on the canvas
        for line_data in lines:
            coords = line_data["coords"]
            color = line_data["color"]
            self.canvas.create_line(coords, fill=color, width=2)

    def update_brightness(self, brightness):
        brightness_factor = 1.0 - (float(brightness) / 100.0)
        adjusted_color = self.adjust_brightness(self.current_color, brightness_factor)
        self.select_color(adjusted_color)

    def adjust_brightness(self, color, brightness_factor):
        r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
        r = min(int(r * brightness_factor), 255)
        g = min(int(g * brightness_factor), 255)
        b = min(int(b * brightness_factor), 255)
        return "#{:02X}{:02X}{:02X}".format(r, g, b)


if __name__ == "__main__":
    root = tk.Tk()
    app = DrawingApp(root)
    root.mainloop()
