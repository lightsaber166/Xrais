import tkinter as tk
from translate import Translator

# Function to perform translation
def translate_text():
    text_to_translate = text_entry.get("1.0", "end-1c")
    source_lang = source_language.get()
    target_lang = target_language.get()

    translator = Translator(to_lang=target_lang, from_lang=source_lang)
    translated_text = translator.translate(text_to_translate)

    translated_text_widget.delete("1.0", "end")
    translated_text_widget.insert("end", translated_text)

# Create the main application window
app = tk.Tk()
app.title("Text Translator")

# Create input text widget
text_entry = tk.Text(app, width=40, height=10)
text_entry.pack()

# Create translation button
translate_button = tk.Button(app, text="Translate", command=translate_text)
translate_button.pack()

# Create a dropdown for source language
source_language_label = tk.Label(app, text="Source Language:")
source_language_label.pack()
source_language = tk.StringVar()
source_language.set("en")  # Default source language (English)
source_language_dropdown = tk.OptionMenu(app, source_language, "en", "es", "fr", "de", "zh")
source_language_dropdown.pack()

# Create a dropdown for target language
target_language_label = tk.Label(app, text="Target Language:")
target_language_label.pack()
target_language = tk.StringVar()
target_language.set("es")  # Default target language (Spanish)
target_language_dropdown = tk.OptionMenu(app, target_language, "en", "es", "fr", "de", "zh")
target_language_dropdown.pack()

# Create a text widget to display translated text
translated_text_widget = tk.Text(app, width=40, height=10)
translated_text_widget.pack()

app.mainloop()
