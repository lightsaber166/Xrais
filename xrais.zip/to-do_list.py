import tkinter as tk

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List App")
        self.tasks = []

        # Create a listbox to display tasks
        self.listbox = tk.Listbox(root, width=50, height=10)
        self.listbox.pack(pady=10)

        # Load tasks from "tasks.txt" if it exists
        self.load_tasks()

        # Create an entry field and buttons
        self.entry = tk.Entry(root, width=40)
        self.entry.pack(pady=5)

        self.add_button = tk.Button(root, text="Add Task", command=self.add_task)
        self.add_button.pack(pady=5)

        self.delete_button = tk.Button(root, text="Delete Task", command=self.delete_task)
        self.delete_button.pack(pady=5)

        # Bind Enter key to add_task
        self.root.bind('<Return>', lambda event=None: self.add_task())

        # Close window button
        close_button = tk.Button(root, text="Close", command=self.close_window)
        close_button.pack(pady=5)

    def add_task(self):
        task = self.entry.get()
        if task:
            self.tasks.append(task)
            self.listbox.insert(tk.END, task)
            self.entry.delete(0, tk.END)
            self.save_tasks()  # Save tasks after adding

    def delete_task(self):
        selected_task = self.listbox.curselection()
        if selected_task:
            index = selected_task[0]
            self.listbox.delete(index)
            del self.tasks[index[0]]
            self.save_tasks()  # Save tasks after deleting

    def save_tasks(self):
        with open("tasks.txt", "w") as file:
            for task in self.tasks:
                file.write(task + '\n')

    def load_tasks(self):
        try:
            with open("tasks.txt", "r") as file:
                self.tasks = file.read().splitlines()
                for task in self.tasks:
                    self.listbox.insert(tk.END, task)
        except FileNotFoundError:
            print("No task file found.")

    def close_window(self):
        self.save_tasks()  # Save tasks before closing
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
