import tkinter as tk
from tkinter import ttk
import calendar
import datetime

def show_calendar():
    current_date = datetime.date.today()
    year = current_date.year
    month = current_date.month
    year_var.set(year)
    month_var.set(month)
    cal_text.config(text=calendar.month(year, month))

def add_goal():
    day = day_entry.get()
    goal = goal_entry.get()
    if day.isdigit() and int(day) in range(1, 32) and goal:
        day_goals.append((int(day), goal))
        update_calendar()
        day_entry.delete(0, tk.END)
        goal_entry.delete(0, tk.END)
        save_goals()

def delete_goal():
    selected_day = cal_tree.selection()
    if selected_day:
        day = int(selected_day[0])
        day_goals[:] = [item for item in day_goals if item[0] != day]
        update_calendar()
        save_goals()

def update_calendar():
    cal_text.config(text=calendar.month(year_var.get(), month_var.get()))
    for item in cal_tree.get_children():
        cal_tree.delete(item)
    for day, goal in day_goals:
        cal_tree.insert("", "end", day, text=f"{day:02d}", values=(goal,))

def save_goals():
    with open("goals.json", "w") as file:
        json.dump(day_goals, file)

def load_goals():
    try:
        with open("goals.json", "r") as file:
            goals = json.load(file)
            day_goals.extend(goals)
            update_calendar()
    except FileNotFoundError:
        pass

app = tk.Tk()
app.title("Calendar App")

year_var = tk.IntVar()
month_var = tk.IntVar()
day_goals = []

year_label = tk.Label(app, text="Year:")
year_label.grid(row=0, column=0)
year_entry = tk.Entry(app, textvariable=year_var)
year_entry.grid(row=0, column=1)

month_label = tk.Label(app, text="Month:")
month_label.grid(row=0, column=2)
month_entry = tk.Entry(app, textvariable=month_var)
month_entry.grid(row=0, column=3)

show_button = tk.Button(app, text="Show Calendar", command=show_calendar)
show_button.grid(row=0, column=4)

cal_text = tk.Label(app, text="", justify="left", anchor="w", padx=20)
cal_text.grid(row=1, column=0, columnspan=5)

day_entry = tk.Entry(app, width=5)
day_entry.grid(row=2, column=0)
goal_entry = tk.Entry(app)
goal_entry.grid(row=2, column=1, columnspan=3)
add_button = tk.Button(app, text="Add Goal", command=add_goal)
add_button.grid(row=2, column=4)

cal_tree = ttk.Treeview(app, columns=("Goal"))
cal_tree.heading("#1", text="Goal")
cal_tree.grid(row=3, column=0, columnspan=5)

delete_button = tk.Button(app, text="Delete Goal", command=delete_goal)
delete_button.grid(row=4, column=0, columnspan=5)

load_goals()

app.mainloop()
