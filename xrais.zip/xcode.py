from tkinter import *
from tkinter.filedialog import asksaveasfilename, askopenfilename
import subprocess
from win32api import GetSystemMetrics
compiler = Tk()
compiler.title('xcode')
filepath = ''

def set_file_path(path):
    global filepath
    filepath = path
def open_file():
    path = askopenfilename(filetypes=[('Python', '*.py')])
    with open(path, 'r') as f:
        code = f.read()
        editor.delete('1.0', END)
        editor.insert('1.0', code)
        set_file_path(path)

def save():
    try:
        with open(filepath, 'w') as f:
            code = editor.get('1.0', END)
            f.write(code)
    except:
        print('no openned file to save')

def save_as():
    path = asksaveasfilename(filetypes=[('Python', '*.py')])
    with open(path, 'w') as f:
        code = editor.get('1.0', END)
        f.write(code)
        set_file_path(path)
def run():
    if filepath == '':
        save_prompt = Toplevel()
        text = Label(save_prompt, text='no file found, please save.')
        text.pack()
        return
    command = f'python {filepath}'
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    output, error = process.communicate()
    code_output.insert('n', output)
    code_output.insert('n', error)

menubar = Menu(compiler)

filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label='Open', command=open_file)
filemenu.add_command(label='save', command=save)
filemenu.add_command(label='save as', command=save_as)
filemenu.add_command(label='Exit', command=exit)
menubar.add_cascade(label='File', menu=filemenu)

runbar = Menu(menubar, tearoff=0)
runbar.add_command(label='Run', command=run)
menubar.add_cascade(label='Run', menu=runbar)

compiler.config(menu=menubar)

editor = Text()
editor.pack()
code_output = Text(height=10)
code_output.pack()
compiler.mainloop()
