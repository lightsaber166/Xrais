import tkinter as tk
import random
import string
import tkinter.messagebox as messagebox

class Hangman:
    def __init__(self, root):
        self.root = root
        self.root.title("Hangman")

        self.wordlist = ["apple", "banana", "cherry", "date", "elderberry", "fig", "grape", "honeydew"]
        self.secret_word = ""
        self.guesses_left = 6
        self.guessed_letters = set()

        self.canvas = tk.Canvas(root, width=200, height=200)
        self.canvas.grid(row=0, column=0, columnspan=4)

        self.word_label = tk.Label(root, text="", font=("Arial", 20))
        self.word_label.grid(row=1, column=0, columnspan=4)

        self.guess_label = tk.Label(root, text="Guess a letter:", font=("Arial", 14))
        self.guess_label.grid(row=2, column=0, sticky=tk.E)

        self.guess_entry = tk.Entry(root, font=("Arial", 14), width=5)
        self.guess_entry.grid(row=2, column=1, sticky=tk.W)

        self.guess_button = tk.Button(root, text="Guess", font=("Arial", 14), command=self.make_guess)
        self.guess_button.grid(row=2, column=2)

        self.restart_button = tk.Button(root, text="Restart", font=("Arial", 14), command=self.restart_game)
        self.restart_button.grid(row=2, column=3)

        self.start_game()

    def start_game(self):
        self.secret_word = random.choice(self.wordlist)
        self.guesses_left = 6
        self.guessed_letters = set()
        self.display_word()
        self.draw_hangman()

    def display_word(self):
        displayed_word = ""
        for letter in self.secret_word:
            if letter in self.guessed_letters:
                displayed_word += letter
            else:
                displayed_word += "_"
        self.word_label.config(text=displayed_word)

    def make_guess(self):
        guess = self.guess_entry.get().lower()
        self.guess_entry.delete(0, tk.END)

        if len(guess) != 1 or guess not in string.ascii_lowercase:
            messagebox.showerror("Invalid Guess", "Please enter a single letter.")
            return

        if guess in self.guessed_letters:
            messagebox.showwarning("Duplicate Guess", "You've already guessed this letter.")
            return

        self.guessed_letters.add(guess)

        if guess not in self.secret_word:
            self.guesses_left -= 1
            self.draw_hangman()

        self.display_word()

        if self.secret_word == "".join([letter if letter in self.guessed_letters else "_" for letter in self.secret_word]):
            messagebox.showinfo("Congratulations!", "You've guessed the word!")
            self.restart_game()

        if self.guesses_left == 0:
            messagebox.showinfo("Game Over", f"The word was '{self.secret_word}'. You're out of guesses!")
            self.restart_game()

    def draw_hangman(self):
        self.canvas.delete("all")
        if self.guesses_left < 6:
            self.canvas.create_line(20, 180, 80, 180, width=2)
        if self.guesses_left < 5:
            self.canvas.create_line(50, 180, 50, 40, width=2)
        if self.guesses_left < 4:
            self.canvas.create_line(50, 40, 100, 40, width=2)
        if self.guesses_left < 3:
            self.canvas.create_line(100, 40, 100, 60, width=2)
        if self.guesses_left < 2:
            self.canvas.create_oval(90, 60, 110, 80, width=2)
        if self.guesses_left < 1:
            self.canvas.create_line(100, 80, 100, 120, width=2)
            self.canvas.create_line(100, 120, 80, 160, width=2)
            self.canvas.create_line(100, 120, 120, 160, width=2)

    def restart_game(self):
        self.canvas.delete("all")
        self.word_label.config(text="")
        self.guess_label.config(text="Guess a letter:")
        self.guess_entry.delete(0, tk.END)
        self.start_game()

if __name__ == "__main__":
    root = tk.Tk()
    game = Hangman(root)
    root.mainloop()
