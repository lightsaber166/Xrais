import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter import Menu
import os

def browse_directory():
    folder_selected = filedialog.askdirectory()
    if folder_selected:
        load_files(folder_selected)

def load_files(directory):
    file_list.delete(*file_list.get_children())
    for item in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, item)):
            file_list.insert("", "end", values=(item, "File"))
        else:
            file_list.insert("", "end", values=(item, "Folder"))

def show_context_menu(event):
    item = file_list.identify("item", event.x, event.y)
    if item:
        selected_item = file_list.item(item, "values")[0]
        item_type = file_list.item(item, "values")[1]

        menu.delete(0, "end")  # Clear the previous menu items

        if item_type == "File":
            menu.add_command(label="Open", command=lambda: open_file(selected_item))
        elif item_type == "Folder":
            menu.add_command(label="Open", command=lambda: open_folder(selected_item))

        menu.add_separator()
        menu.add_command(label="Delete", command=lambda: delete_item(selected_item))
        menu.post(event.x_root, event.y_root)

def open_file(file_path):
    os.startfile(file_path)

def open_folder(folder_path):
    os.system(f"start explorer {folder_path}")

def delete_item(item_path):
    item_type = "File" if os.path.isfile(item_path) else "Folder"
    if item_type == "File":
        os.remove(item_path)
    else:
        os.rmdir(item_path)
    file_list.delete(item_path)

app = tk.Tk()
app.title("File Explorer")

browse_button = ttk.Button(app, text="Browse", command=browse_directory)
browse_button.pack(pady=10)

file_list = ttk.Treeview(app, columns=("Name", "Type"), show="headings")
file_list.heading("Name", text="Name")
file_list.heading("Type", text="Type")
file_list.pack(padx=10, pady=5, fill="both", expand=True)

menu = Menu(app, tearoff=0)

file_list.bind("<Button-3>", show_context_menu)

app.mainloop()
